import React from 'react';
import { TrendingUp, AlertTriangle, CheckCircle, ArrowRight } from 'lucide-react';

export default function Dashboard() {
  const currentTopic = "Binary Search Trees";
  const weekTopics = ['Arrays', 'Linked Lists', 'Stacks', 'Queues', 'Binary Trees'];
  const masteryData = [
    { topic: 'Arrays', mastery: 95, status: 'excellent' },
    { topic: 'Linked Lists', mastery: 78, status: 'good' },
    { topic: 'Stacks', mastery: 65, status: 'average' },
    { topic: 'Queues', mastery: 45, status: 'weak' },
    { topic: 'Binary Trees', mastery: 30, status: 'weak' }
  ];

  const performanceData = [40, 55, 60, 75, 70, 85, 90];
  const maxPerformance = Math.max(...performanceData);

  return (
    <section id="dashboard" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">AI Learning Dashboard</h2>
          <p className="text-lg text-gray-600">Track your progress and identify areas for improvement</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Current Progress */}
          <div className="lg:col-span-2 space-y-6">
            {/* Current Topic */}
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Currently Learning</h3>
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-2xl font-bold text-blue-600">{currentTopic}</h4>
                  <p className="text-gray-600">Data Structures</p>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-purple-600">67%</div>
                  <div className="text-sm text-gray-600">Progress</div>
                </div>
              </div>
            </div>

            {/* Mastery Progress */}
            <div className="bg-white border border-gray-200 rounded-2xl p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Topic Mastery</h3>
              <div className="space-y-4">
                {masteryData.map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${
                        item.status === 'excellent' ? 'bg-green-500' :
                        item.status === 'good' ? 'bg-blue-500' :
                        item.status === 'average' ? 'bg-yellow-500' : 'bg-red-500'
                      }`}></div>
                      <span className="text-gray-900 font-medium">{item.topic}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            item.status === 'excellent' ? 'bg-green-500' :
                            item.status === 'good' ? 'bg-blue-500' :
                            item.status === 'average' ? 'bg-yellow-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${item.mastery}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-semibold text-gray-700 w-10">{item.mastery}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Performance Graph */}
            <div className="bg-white border border-gray-200 rounded-2xl p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Performance Over Time</h3>
              <div className="flex items-end space-x-2 h-48">
                {performanceData.map((value, index) => (
                  <div key={index} className="flex-1 flex flex-col items-center">
                    <div 
                      className="w-full bg-gradient-to-t from-blue-500 to-purple-600 rounded-t-lg transition-all duration-500"
                      style={{ height: `${(value / maxPerformance) * 100}%` }}
                    ></div>
                    <span className="text-xs text-gray-600 mt-2">Day {index + 1}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Weak Topics Alert */}
            <div className="bg-red-50 border border-red-200 rounded-2xl p-6">
              <div className="flex items-center space-x-3 mb-4">
                <AlertTriangle className="h-6 w-6 text-red-600" />
                <h3 className="text-lg font-semibold text-red-800">Needs Attention</h3>
              </div>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-red-700">Queues</span>
                  <span className="text-sm text-red-600">45%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-red-700">Binary Trees</span>
                  <span className="text-sm text-red-600">30%</span>
                </div>
              </div>
              <button className="w-full mt-4 bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 transition-colors">
                Review Weak Topics
              </button>
            </div>

            {/* Next Suggested Lesson */}
            <div className="bg-green-50 border border-green-200 rounded-2xl p-6">
              <div className="flex items-center space-x-3 mb-4">
                <CheckCircle className="h-6 w-6 text-green-600" />
                <h3 className="text-lg font-semibold text-green-800">Next Lesson</h3>
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Tree Traversal Techniques</h4>
              <p className="text-sm text-gray-600 mb-4">Learn in-order, pre-order, and post-order traversal methods</p>
              <button className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center space-x-2">
                <span>Start Lesson</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>

            {/* Weekly Goals */}
            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-6">
              <h3 className="text-lg font-semibold text-blue-800 mb-4">This Week's Goals</h3>
              <div className="space-y-3">
                {weekTopics.map((topic, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className={`w-4 h-4 rounded-full ${index < 2 ? 'bg-green-500' : 'border-2 border-blue-300'}`}>
                      {index < 2 && <CheckCircle className="h-3 w-3 text-white m-0.5" />}
                    </div>
                    <span className={`text-sm ${index < 2 ? 'line-through text-gray-500' : 'text-gray-700'}`}>
                      {topic}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}