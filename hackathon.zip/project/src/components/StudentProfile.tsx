import React, { useState } from 'react';
import { Edit3, User, GraduationCap, Calendar } from 'lucide-react';

export default function StudentProfile() {
  const [isEditing, setIsEditing] = useState(false);
  const [selectedSubjects, setSelectedSubjects] = useState([
    'Data Structures', 'Machine Learning', 'Database Management'
  ]);

  const subjects = [
    'Data Structures', 'Machine Learning', 'Database Management', 'Cloud Computing',
    'Computer Networks', 'Operating Systems', 'Software Engineering', 'Artificial Intelligence',
    'Web Development', 'Mobile App Development'
  ];

  const toggleSubject = (subject: string) => {
    setSelectedSubjects(prev =>
      prev.includes(subject)
        ? prev.filter(s => s !== subject)
        : [...prev, subject]
    );
  };

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-2xl p-8">
          <div className="flex flex-col lg:flex-row items-start space-y-6 lg:space-y-0 lg:space-x-8">
            {/* Profile Info */}
            <div className="flex flex-col items-center lg:items-start space-y-4">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg">
                <User className="h-12 w-12 text-white" />
              </div>
              
              <div className="text-center lg:text-left">
                <h2 className="text-2xl font-bold text-gray-900">Priya Sharma</h2>
                <div className="flex items-center space-x-2 text-gray-600 mt-1">
                  <GraduationCap className="h-4 w-4" />
                  <span>B.Tech Computer Science</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-600 mt-1">
                  <Calendar className="h-4 w-4" />
                  <span>Semester 6</span>
                </div>
              </div>

              <button 
                onClick={() => setIsEditing(!isEditing)}
                className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all"
              >
                <Edit3 className="h-4 w-4" />
                <span>Edit Profile</span>
              </button>
            </div>

            {/* Subject Preferences */}
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Subject Preferences</h3>
              {isEditing ? (
                <div className="space-y-3">
                  <p className="text-sm text-gray-600 mb-4">Select subjects you want to focus on:</p>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {subjects.map((subject) => (
                      <label key={subject} className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedSubjects.includes(subject)}
                          onChange={() => toggleSubject(subject)}
                          className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                        />
                        <span className="text-sm text-gray-700">{subject}</span>
                      </label>
                    ))}
                  </div>
                  <div className="flex space-x-4 mt-6">
                    <button 
                      onClick={() => setIsEditing(false)}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      Save Changes
                    </button>
                    <button 
                      onClick={() => setIsEditing(false)}
                      className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {selectedSubjects.map((subject) => (
                    <span
                      key={subject}
                      className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium"
                    >
                      {subject}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}