import React, { useState } from 'react';
import { Calendar, CheckCircle, Clock, Bell } from 'lucide-react';

export default function RevisionPlanner() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [completedTopics, setCompletedTopics] = useState<string[]>([]);

  const revisionSchedule = [
    {
      date: '2024-01-15',
      topics: ['Arrays Basics', 'Time Complexity'],
      status: 'completed',
      subject: 'Data Structures'
    },
    {
      date: '2024-01-16',
      topics: ['Linked Lists', 'Pointers'],
      status: 'completed',
      subject: 'Data Structures'
    },
    {
      date: '2024-01-17',
      topics: ['Stack Operations', 'Queue Implementation'],
      status: 'pending',
      subject: 'Data Structures'
    },
    {
      date: '2024-01-18',
      topics: ['Binary Trees', 'Tree Traversal'],
      status: 'upcoming',
      subject: 'Data Structures'
    },
    {
      date: '2024-01-19',
      topics: ['SQL Basics', 'Database Design'],
      status: 'upcoming',
      subject: 'Database Management'
    }
  ];

  const upcomingReminders = [
    {
      topic: 'Binary Search Trees Review',
      date: 'Today, 2:00 PM',
      subject: 'Data Structures',
      priority: 'high'
    },
    {
      topic: 'ML Algorithms Quiz',
      date: 'Tomorrow, 10:00 AM',
      subject: 'Machine Learning',
      priority: 'medium'
    },
    {
      topic: 'Database Normalization',
      date: 'Jan 20, 3:00 PM',
      subject: 'Database Management',
      priority: 'low'
    }
  ];

  const toggleTopicCompletion = (topic: string) => {
    setCompletedTopics(prev =>
      prev.includes(topic)
        ? prev.filter(t => t !== topic)
        : [...prev, topic]
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'upcoming': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Calendar className="h-8 w-8 text-blue-600" />
            <h2 className="text-3xl font-bold text-gray-900">Revision Planner</h2>
          </div>
          <p className="text-lg text-gray-600">Stay on track with your study schedule</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calendar View */}
          <div className="lg:col-span-2">
            <div className="bg-white border border-gray-200 rounded-2xl p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Revision Schedule</h3>
              
              <div className="space-y-4">
                {revisionSchedule.map((item, index) => (
                  <div key={index} className={`border-2 rounded-xl p-4 ${getStatusColor(item.status)}`}>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="text-sm font-semibold">
                          {new Date(item.date).toLocaleDateString('en-US', { 
                            weekday: 'short', 
                            month: 'short', 
                            day: 'numeric' 
                          })}
                        </div>
                        <span className="text-xs px-2 py-1 bg-white/50 rounded-full">
                          {item.subject}
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {item.status === 'completed' && (
                          <CheckCircle className="h-5 w-5 text-green-600" />
                        )}
                        {item.status === 'pending' && (
                          <Clock className="h-5 w-5 text-yellow-600" />
                        )}
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      {item.topics.map((topic, topicIndex) => (
                        <div key={topicIndex} className="flex items-center justify-between">
                          <span className={`text-sm ${item.status === 'completed' ? 'line-through' : ''}`}>
                            {topic}
                          </span>
                          {item.status === 'pending' && (
                            <button
                              onClick={() => toggleTopicCompletion(topic)}
                              className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                                completedTopics.includes(topic)
                                  ? 'bg-green-600 text-white'
                                  : 'bg-white/70 hover:bg-white'
                              }`}
                            >
                              {completedTopics.includes(topic) ? 'Done' : 'Mark Done'}
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Progress Overview */}
            <div className="mt-8 bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">This Week's Progress</h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">3</div>
                  <div className="text-sm text-gray-600">Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-600">1</div>
                  <div className="text-sm text-gray-600">In Progress</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">2</div>
                  <div className="text-sm text-gray-600">Upcoming</div>
                </div>
              </div>
              <div className="mt-4">
                <div className="flex justify-between text-sm mb-2">
                  <span>Weekly Goal</span>
                  <span>60%</span>
                </div>
                <div className="w-full bg-white rounded-full h-3">
                  <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-full h-3" style={{ width: '60%' }}></div>
                </div>
              </div>
            </div>
          </div>

          {/* Reminders Sidebar */}
          <div className="space-y-6">
            <div className="bg-white border border-gray-200 rounded-2xl p-6">
              <div className="flex items-center space-x-2 mb-4">
                <Bell className="h-5 w-5 text-orange-600" />
                <h3 className="text-lg font-semibold text-gray-900">Upcoming Reminders</h3>
              </div>
              
              <div className="space-y-4">
                {upcomingReminders.map((reminder, index) => (
                  <div key={index} className={`border-2 rounded-xl p-4 ${getPriorityColor(reminder.priority)}`}>
                    <h4 className="font-semibold text-sm mb-1">{reminder.topic}</h4>
                    <p className="text-xs mb-2">{reminder.subject}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs">{reminder.date}</span>
                      <span className="text-xs font-semibold capitalize">{reminder.priority}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white border border-gray-200 rounded-2xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <button className="w-full px-4 py-3 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors text-sm font-medium">
                  Add Custom Reminder
                </button>
                <button className="w-full px-4 py-3 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors text-sm font-medium">
                  Generate Study Plan
                </button>
                <button className="w-full px-4 py-3 bg-purple-100 text-purple-800 rounded-lg hover:bg-purple-200 transition-colors text-sm font-medium">
                  Export Calendar
                </button>
              </div>
            </div>

            {/* Study Streak */}
            <div className="bg-gradient-to-br from-orange-50 to-red-50 border border-orange-200 rounded-2xl p-6">
              <h3 className="text-lg font-semibold text-orange-800 mb-4">Study Streak</h3>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600 mb-2">7 Days</div>
                <p className="text-sm text-orange-700">Keep it up! You're on fire! 🔥</p>
                <div className="flex justify-center space-x-1 mt-3">
                  {[...Array(7)].map((_, i) => (
                    <div key={i} className="w-3 h-3 bg-orange-500 rounded-full"></div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}