import React, { useState } from 'react';
import { Play, CheckCircle, XCircle, RefreshCw, Lightbulb } from 'lucide-react';

export default function QuizSection() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState('');
  const [showFeedback, setShowFeedback] = useState(false);
  const [quizStarted, setQuizStarted] = useState(false);

  const questions = [
    {
      question: "What is the time complexity of searching in a binary search tree?",
      options: ["O(n)", "O(log n)", "O(n²)", "O(1)"],
      correct: "O(log n)",
      explanation: "In a balanced BST, search operations take O(log n) time because we eliminate half of the remaining nodes at each step.",
      difficulty: "Medium"
    },
    {
      question: "Which data structure uses LIFO principle?",
      options: ["Queue", "Stack", "Array", "Linked List"],
      correct: "Stack",
      explanation: "Stack follows Last In First Out (LIFO) principle where the last element added is the first one to be removed.",
      difficulty: "Easy"
    }
  ];

  const handleStartQuiz = () => {
    setQuizStarted(true);
    setCurrentQuestion(0);
    setSelectedAnswer('');
    setShowFeedback(false);
  };

  const handleAnswerSelect = (answer: string) => {
    setSelectedAnswer(answer);
    setShowFeedback(true);
  };

  const isCorrect = selectedAnswer === questions[currentQuestion]?.correct;

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Practice & Quiz</h2>
          <p className="text-lg text-gray-600">Test your knowledge with adaptive difficulty</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          {!quizStarted ? (
            <div className="p-12 text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <Play className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Ready to Test Your Knowledge?</h3>
              <p className="text-gray-600 mb-8 max-w-md mx-auto">
                Our AI will adapt the difficulty based on your performance to ensure optimal learning.
              </p>
              <button 
                onClick={handleStartQuiz}
                className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-4 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-700 transition-all transform hover:scale-105"
              >
                Start Quiz
              </button>
            </div>
          ) : (
            <div className="p-8">
              {/* Progress Bar */}
              <div className="mb-8">
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>Question {currentQuestion + 1} of {questions.length}</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                    questions[currentQuestion]?.difficulty === 'Easy' ? 'bg-green-100 text-green-800' :
                    questions[currentQuestion]?.difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {questions[currentQuestion]?.difficulty}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
                  ></div>
                </div>
              </div>

              {/* Question */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-6">
                  {questions[currentQuestion]?.question}
                </h3>
                <div className="space-y-3">
                  {questions[currentQuestion]?.options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() => !showFeedback && handleAnswerSelect(option)}
                      disabled={showFeedback}
                      className={`w-full p-4 text-left border-2 rounded-xl transition-all ${
                        !showFeedback 
                          ? 'border-gray-200 hover:border-blue-300 hover:bg-blue-50' 
                          : option === questions[currentQuestion]?.correct
                            ? 'border-green-500 bg-green-50 text-green-800'
                            : option === selectedAnswer && !isCorrect
                              ? 'border-red-500 bg-red-50 text-red-800'
                              : 'border-gray-200 bg-gray-50 text-gray-500'
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                          showFeedback && option === questions[currentQuestion]?.correct
                            ? 'border-green-500 bg-green-500'
                            : showFeedback && option === selectedAnswer && !isCorrect
                              ? 'border-red-500 bg-red-500'
                              : 'border-gray-300'
                        }`}>
                          {showFeedback && option === questions[currentQuestion]?.correct && 
                            <CheckCircle className="h-4 w-4 text-white" />}
                          {showFeedback && option === selectedAnswer && !isCorrect && 
                            <XCircle className="h-4 w-4 text-white" />}
                        </div>
                        <span className="font-medium">{option}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Feedback */}
              {showFeedback && (
                <div className={`p-6 rounded-xl mb-6 ${
                  isCorrect ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
                }`}>
                  <div className="flex items-start space-x-3">
                    <Lightbulb className={`h-6 w-6 mt-0.5 ${isCorrect ? 'text-green-600' : 'text-red-600'}`} />
                    <div>
                      <h4 className={`font-semibold mb-2 ${isCorrect ? 'text-green-800' : 'text-red-800'}`}>
                        {isCorrect ? 'Correct!' : 'Incorrect'}
                      </h4>
                      <p className={`text-sm ${isCorrect ? 'text-green-700' : 'text-red-700'}`}>
                        {questions[currentQuestion]?.explanation}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex justify-between">
                <button className="flex items-center space-x-2 px-6 py-3 bg-orange-100 text-orange-700 rounded-lg hover:bg-orange-200 transition-colors">
                  <RefreshCw className="h-4 w-4" />
                  <span>Retry Weak Questions</span>
                </button>
                
                {showFeedback && (
                  <button 
                    onClick={() => {
                      if (currentQuestion < questions.length - 1) {
                        setCurrentQuestion(currentQuestion + 1);
                        setSelectedAnswer('');
                        setShowFeedback(false);
                      } else {
                        setQuizStarted(false);
                      }
                    }}
                    className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    {currentQuestion < questions.length - 1 ? 'Next Question' : 'Finish Quiz'}
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}