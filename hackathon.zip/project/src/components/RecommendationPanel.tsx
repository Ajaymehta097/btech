import React from 'react';
import { Bot, ArrowRight, TrendingUp, AlertCircle } from 'lucide-react';

export default function RecommendationPanel() {
  const recommendations = [
    {
      type: 'weakness',
      icon: AlertCircle,
      title: 'Improve Queue Operations',
      message: "Because you scored low in Queue operations, we suggest reviewing the 'Queue Implementation and Applications' lesson.",
      action: 'Review Lesson',
      color: 'from-red-500 to-orange-500',
      bgColor: 'bg-red-50 border-red-200',
      textColor: 'text-red-800'
    },
    {
      type: 'next',
      icon: TrendingUp,
      title: 'Ready for Advanced Topics',
      message: "Great progress on Binary Trees! Next: Advanced Tree Traversal because you've mastered the basics.",
      action: 'Start Advanced Topic',
      color: 'from-green-500 to-blue-500',
      bgColor: 'bg-green-50 border-green-200',
      textColor: 'text-green-800'
    },
    {
      type: 'practice',
      icon: Bot,
      title: 'Practice Recommendation',
      message: "You're doing well with Arrays! Try some challenging problems to strengthen your problem-solving skills.",
      action: 'Start Practice',
      color: 'from-blue-500 to-purple-500',
      bgColor: 'bg-blue-50 border-blue-200',
      textColor: 'text-blue-800'
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Bot className="h-8 w-8 text-blue-600" />
            <h2 className="text-3xl font-bold text-gray-900">AI Recommendations</h2>
          </div>
          <p className="text-lg text-gray-600">Personalized suggestions based on your learning progress</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {recommendations.map((rec, index) => (
            <div key={index} className={`${rec.bgColor} border rounded-2xl p-6 hover:shadow-lg transition-all`}>
              <div className="flex items-start space-x-4">
                <div className={`bg-gradient-to-r ${rec.color} p-3 rounded-full flex-shrink-0`}>
                  <rec.icon className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className={`text-lg font-semibold ${rec.textColor} mb-2`}>
                    {rec.title}
                  </h3>
                  <p className="text-gray-700 text-sm leading-relaxed mb-4">
                    {rec.message}
                  </p>
                  <button className={`bg-gradient-to-r ${rec.color} text-white px-4 py-2 rounded-lg font-medium hover:shadow-md transition-all flex items-center space-x-2 text-sm`}>
                    <span>{rec.action}</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* AI Chat Interface */}
        <div className="mt-12 bg-gradient-to-br from-gray-50 to-blue-50 rounded-2xl p-8">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                <Bot className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-900">AI Learning Assistant</h3>
                <p className="text-sm text-gray-600">Ask me anything about your studies!</p>
              </div>
            </div>

            <div className="bg-white rounded-xl p-4 mb-4 max-w-3xl">
              <p className="text-gray-800">
                "I notice you're struggling with graph algorithms. Would you like me to create a personalized study plan focusing on BFS and DFS with visual examples?"
              </p>
              <div className="flex space-x-3 mt-3">
                <button className="px-4 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors text-sm">
                  Yes, create plan
                </button>
                <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm">
                  Show examples first
                </button>
              </div>
            </div>

            <div className="flex space-x-4">
              <input
                type="text"
                placeholder="Ask your AI tutor anything..."
                className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-700 transition-all">
                Send
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}