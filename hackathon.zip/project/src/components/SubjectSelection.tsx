import React from 'react';
import { Play, Clock, Star } from 'lucide-react';

export default function SubjectSelection() {
  const subjects = [
    {
      name: 'Data Structures',
      semester: '3rd Semester',
      progress: 75,
      difficulty: 'Intermediate',
      topics: 24,
      color: 'from-blue-500 to-blue-600'
    },
    {
      name: 'Machine Learning',
      semester: '6th Semester',
      progress: 45,
      difficulty: 'Advanced',
      topics: 18,
      color: 'from-purple-500 to-purple-600'
    },
    {
      name: 'Database Management',
      semester: '4th Semester',
      progress: 90,
      difficulty: 'Intermediate',
      topics: 20,
      color: 'from-green-500 to-green-600'
    },
    {
      name: 'Cloud Computing',
      semester: '7th Semester',
      progress: 20,
      difficulty: 'Advanced',
      topics: 15,
      color: 'from-orange-500 to-orange-600'
    }
  ];

  return (
    <section id="subjects" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Choose Your Subjects</h2>
          <p className="text-lg text-gray-600">Start your personalized learning journey</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {subjects.map((subject, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all transform hover:scale-105 overflow-hidden">
              <div className={`bg-gradient-to-r ${subject.color} p-6 text-white`}>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-bold mb-2">{subject.name}</h3>
                    <p className="text-blue-100">{subject.semester}</p>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 fill-current" />
                    <span className="text-sm">{subject.difficulty}</span>
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Progress</span>
                    <span>{subject.progress}%</span>
                  </div>
                  <div className="w-full bg-white/30 rounded-full h-2">
                    <div 
                      className="bg-white rounded-full h-2 transition-all duration-500" 
                      style={{ width: `${subject.progress}%` }}
                    ></div>
                  </div>
                </div>
              </div>

              <div className="p-6">
                <div className="flex items-center space-x-2 text-gray-600 mb-4">
                  <Clock className="h-4 w-4" />
                  <span className="text-sm">{subject.topics} Topics</span>
                </div>

                <button className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 rounded-lg font-semibold hover:from-blue-600 hover:to-purple-700 transition-all flex items-center justify-center space-x-2">
                  <Play className="h-5 w-5" />
                  <span>Start Learning</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}