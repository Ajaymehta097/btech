import React, { useState } from 'react';
import { Users, Download, BookOpen, AlertTriangle, TrendingUp, Send } from 'lucide-react';

interface TeacherDashboardProps {
  isVisible: boolean;
}

export default function TeacherDashboard({ isVisible }: TeacherDashboardProps) {
  const [selectedStudent, setSelectedStudent] = useState<string>('');

  const studentsData = [
    {
      id: '1',
      name: 'Priya Sharma',
      semester: 'B.Tech CSE - 6th Sem',
      weakTopics: ['Queues', 'Binary Trees', 'Graph Algorithms'],
      overallProgress: 78,
      lastActive: '2 hours ago',
      avgScore: 85
    },
    {
      id: '2',
      name: 'Arjun Patel',
      semester: 'B.Tech CSE - 6th Sem',
      weakTopics: ['Dynamic Programming', 'Greedy Algorithms'],
      overallProgress: 65,
      lastActive: '1 day ago',
      avgScore: 72
    },
    {
      id: '3',
      name: 'Sneha Reddy',
      semester: 'M.Tech AI - 2nd Sem',
      weakTopics: ['Neural Networks', 'Deep Learning'],
      overallProgress: 92,
      lastActive: '30 mins ago',
      avgScore: 94
    },
    {
      id: '4',
      name: 'Rahul Kumar',
      semester: 'B.Tech CSE - 6th Sem',
      weakTopics: ['Database Normalization', 'SQL Joins'],
      overallProgress: 58,
      lastActive: '3 hours ago',
      avgScore: 68
    }
  ];

  const classAnalytics = {
    totalStudents: 45,
    averageProgress: 73,
    completionRate: 67,
    activeToday: 32
  };

  if (!isVisible) return null;

  return (
    <section className="py-16 bg-gradient-to-br from-indigo-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Users className="h-8 w-8 text-indigo-600" />
            <h2 className="text-3xl font-bold text-gray-900">Teacher Dashboard</h2>
          </div>
          <p className="text-lg text-gray-600">Monitor student progress and provide targeted assistance</p>
        </div>

        {/* Class Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Students</p>
                <p className="text-3xl font-bold text-indigo-600">{classAnalytics.totalStudents}</p>
              </div>
              <Users className="h-12 w-12 text-indigo-600 opacity-50" />
            </div>
          </div>
          
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Progress</p>
                <p className="text-3xl font-bold text-blue-600">{classAnalytics.averageProgress}%</p>
              </div>
              <TrendingUp className="h-12 w-12 text-blue-600 opacity-50" />
            </div>
          </div>
          
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Completion Rate</p>
                <p className="text-3xl font-bold text-green-600">{classAnalytics.completionRate}%</p>
              </div>
              <BookOpen className="h-12 w-12 text-green-600 opacity-50" />
            </div>
          </div>
          
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Today</p>
                <p className="text-3xl font-bold text-purple-600">{classAnalytics.activeToday}</p>
              </div>
              <Users className="h-12 w-12 text-purple-600 opacity-50" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Students Table */}
          <div className="lg:col-span-2 bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Student Progress Overview</h3>
              <button className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                <Download className="h-4 w-4" />
                <span>Download Report</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-2 font-semibold text-gray-900">Student</th>
                    <th className="text-left py-3 px-2 font-semibold text-gray-900">Progress</th>
                    <th className="text-left py-3 px-2 font-semibold text-gray-900">Weak Topics</th>
                    <th className="text-left py-3 px-2 font-semibold text-gray-900">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {studentsData.map((student) => (
                    <tr key={student.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-2">
                        <div>
                          <p className="font-semibold text-gray-900">{student.name}</p>
                          <p className="text-sm text-gray-600">{student.semester}</p>
                          <p className="text-xs text-gray-500">Last active: {student.lastActive}</p>
                        </div>
                      </td>
                      <td className="py-4 px-2">
                        <div className="flex items-center space-x-3">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div 
                              className={`h-2 rounded-full ${
                                student.overallProgress >= 80 ? 'bg-green-500' :
                                student.overallProgress >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                              }`}
                              style={{ width: `${student.overallProgress}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-semibold text-gray-700">
                            {student.overallProgress}%
                          </span>
                        </div>
                      </td>
                      <td className="py-4 px-2">
                        <div className="flex flex-wrap gap-1">
                          {student.weakTopics.slice(0, 2).map((topic, index) => (
                            <span 
                              key={index}
                              className="px-2 py-1 bg-red-100 text-red-700 rounded-full text-xs font-medium"
                            >
                              {topic}
                            </span>
                          ))}
                          {student.weakTopics.length > 2 && (
                            <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs">
                              +{student.weakTopics.length - 2}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-4 px-2">
                        <button 
                          onClick={() => setSelectedStudent(student.id)}
                          className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-lg hover:bg-indigo-200 transition-colors text-sm font-medium"
                        >
                          Assign Lesson
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Action Panel */}
          <div className="space-y-6">
            {/* At-Risk Students */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <div className="flex items-center space-x-2 mb-4">
                <AlertTriangle className="h-5 w-5 text-red-600" />
                <h3 className="text-lg font-semibold text-gray-900">At-Risk Students</h3>
              </div>
              
              <div className="space-y-3">
                {studentsData
                  .filter(student => student.overallProgress < 70)
                  .map((student) => (
                    <div key={student.id} className="flex items-center justify-between p-3 bg-red-50 border border-red-200 rounded-lg">
                      <div>
                        <p className="font-semibold text-red-800 text-sm">{student.name}</p>
                        <p className="text-xs text-red-600">{student.overallProgress}% progress</p>
                      </div>
                      <button className="px-3 py-1 bg-red-600 text-white rounded text-xs font-medium hover:bg-red-700 transition-colors">
                        Help
                      </button>
                    </div>
                  ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <button className="w-full px-4 py-3 bg-indigo-100 text-indigo-800 rounded-lg hover:bg-indigo-200 transition-colors text-sm font-medium flex items-center justify-center space-x-2">
                  <BookOpen className="h-4 w-4" />
                  <span>Create Assignment</span>
                </button>
                
                <button className="w-full px-4 py-3 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors text-sm font-medium flex items-center justify-center space-x-2">
                  <Send className="h-4 w-4" />
                  <span>Send Announcement</span>
                </button>
                
                <button className="w-full px-4 py-3 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors text-sm font-medium flex items-center justify-center space-x-2">
                  <TrendingUp className="h-4 w-4" />
                  <span>View Analytics</span>
                </button>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
              <div className="space-y-3">
                <div className="text-sm">
                  <p className="font-medium text-gray-900">Priya Sharma</p>
                  <p className="text-gray-600">Completed "Binary Trees" quiz</p>
                  <p className="text-xs text-gray-500">2 hours ago</p>
                </div>
                <div className="text-sm">
                  <p className="font-medium text-gray-900">Sneha Reddy</p>
                  <p className="text-gray-600">Started "Neural Networks" module</p>
                  <p className="text-xs text-gray-500">30 minutes ago</p>
                </div>
                <div className="text-sm">
                  <p className="font-medium text-gray-900">Arjun Patel</p>
                  <p className="text-gray-600">Requested help on DP problems</p>
                  <p className="text-xs text-gray-500">1 day ago</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}