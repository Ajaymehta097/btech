import React from 'react';
import { ExternalLink, Clock, Users, Star } from 'lucide-react';

export default function ProjectsSection() {
  const projects = [
    {
      title: 'Mini Library Management System',
      description: 'Build a complete DBMS project with user authentication, book inventory, and borrowing system.',
      subject: 'Database Management',
      difficulty: 'Intermediate',
      duration: '2 weeks',
      team: '2-3 students',
      skills: ['SQL', 'Database Design', 'PHP', 'HTML/CSS'],
      rating: 4.5,
      color: 'from-green-500 to-teal-500'
    },
    {
      title: 'Student Grade Prediction ML Model',
      description: 'Create a machine learning model to predict student performance based on study patterns and past grades.',
      subject: 'Machine Learning',
      difficulty: 'Advanced',
      duration: '3 weeks',
      team: '3-4 students',
      skills: ['Python', 'Scikit-learn', 'Data Analysis', 'Visualization'],
      rating: 4.7,
      color: 'from-purple-500 to-indigo-500'
    },
    {
      title: 'Social Media Analytics Dashboard',
      description: 'Build a real-time dashboard to analyze social media trends using data structures and algorithms.',
      subject: 'Data Structures',
      difficulty: 'Advanced',
      duration: '4 weeks',
      team: '2-4 students',
      skills: ['JavaScript', 'React', 'APIs', 'Data Structures'],
      rating: 4.3,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      title: 'Cloud Storage System',
      description: 'Implement a scalable file storage system using cloud technologies with microservices architecture.',
      subject: 'Cloud Computing',
      difficulty: 'Expert',
      duration: '5 weeks',
      team: '4-5 students',
      skills: ['AWS/Azure', 'Docker', 'Microservices', 'REST APIs'],
      rating: 4.8,
      color: 'from-orange-500 to-red-500'
    }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Intermediate': return 'bg-yellow-100 text-yellow-800';
      case 'Advanced': return 'bg-orange-100 text-orange-800';
      case 'Expert': return 'bg-red-100 text-red-800';
      default: return 'bg-green-100 text-green-800';
    }
  };

  return (
    <section id="projects" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Recommended Projects</h2>
          <p className="text-lg text-gray-600">Apply your knowledge with real-world projects</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all overflow-hidden">
              <div className={`bg-gradient-to-r ${project.color} p-6 text-white`}>
                <div className="flex justify-between items-start mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                    <p className="text-blue-100">{project.subject}</p>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 fill-current" />
                    <span className="text-sm">{project.rating}</span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4 text-sm">
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{project.duration}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="h-4 w-4" />
                    <span>{project.team}</span>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-semibold bg-white/20`}>
                    {project.difficulty}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <p className="text-gray-600 mb-6 leading-relaxed">
                  {project.description}
                </p>

                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-gray-900 mb-3">Skills You'll Learn:</h4>
                  <div className="flex flex-wrap gap-2">
                    {project.skills.map((skill, skillIndex) => (
                      <span
                        key={skillIndex}
                        className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm font-medium"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                <button className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 rounded-lg font-semibold hover:from-blue-600 hover:to-purple-700 transition-all flex items-center justify-center space-x-2">
                  <span>View Details</span>
                  <ExternalLink className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Project Skills Overview */}
        <div className="mt-16 bg-white rounded-2xl shadow-lg p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Project-Based Skill Development</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-white">4</span>
              </div>
              <h4 className="font-semibold text-gray-900">Live Projects</h4>
              <p className="text-sm text-gray-600 mt-1">Real-world applications</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-white">15+</span>
              </div>
              <h4 className="font-semibold text-gray-900">Technologies</h4>
              <p className="text-sm text-gray-600 mt-1">Modern tech stack</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-white">3</span>
              </div>
              <h4 className="font-semibold text-gray-900">Difficulty Levels</h4>
              <p className="text-sm text-gray-600 mt-1">Progressive learning</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-white">∞</span>
              </div>
              <h4 className="font-semibold text-gray-900">Portfolio</h4>
              <p className="text-sm text-gray-600 mt-1">Career-ready work</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}