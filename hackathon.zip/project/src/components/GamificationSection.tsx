import React from 'react';
import { Trophy, Medal, Star, Award, Crown, Target } from 'lucide-react';

export default function GamificationSection() {
  const userBadges = [
    {
      name: 'Data Structures Master',
      description: 'Completed all DS topics',
      icon: Trophy,
      earned: true,
      type: 'gold',
      date: 'Jan 10, 2024'
    },
    {
      name: 'Quiz Champion',
      description: '10 perfect quiz scores',
      icon: Crown,
      earned: true,
      type: 'gold',
      date: 'Jan 12, 2024'
    },
    {
      name: 'Consistency Star',
      description: '7-day learning streak',
      icon: Star,
      earned: true,
      type: 'silver',
      date: 'Jan 15, 2024'
    },
    {
      name: 'Problem Solver',
      description: 'Solved 50 coding problems',
      icon: Target,
      earned: true,
      type: 'silver',
      date: 'Jan 8, 2024'
    },
    {
      name: 'ML Apprentice',
      description: 'Started ML fundamentals',
      icon: Award,
      earned: true,
      type: 'bronze',
      date: 'Jan 5, 2024'
    },
    {
      name: 'Database Designer',
      description: 'Master database concepts',
      icon: Medal,
      earned: false,
      type: 'gold',
      progress: 75
    }
  ];

  const leaderboard = [
    {
      rank: 1,
      name: 'Sneha Reddy',
      points: 2840,
      streak: 15,
      avatar: 'SR',
      change: 'up'
    },
    {
      rank: 2,
      name: 'Priya Sharma',
      points: 2650,
      streak: 7,
      avatar: 'PS',
      change: 'same'
    },
    {
      rank: 3,
      name: 'Arjun Patel',
      points: 2520,
      streak: 12,
      avatar: 'AP',
      change: 'up'
    },
    {
      rank: 4,
      name: 'Rahul Kumar',
      points: 2310,
      streak: 4,
      avatar: 'RK',
      change: 'down'
    },
    {
      rank: 5,
      name: 'Anita Singh',
      points: 2180,
      streak: 8,
      avatar: 'AS',
      change: 'up'
    }
  ];

  const getBadgeColor = (type: string, earned: boolean) => {
    if (!earned) return 'from-gray-400 to-gray-500';
    
    switch (type) {
      case 'gold': return 'from-yellow-400 to-yellow-600';
      case 'silver': return 'from-gray-300 to-gray-500';
      case 'bronze': return 'from-orange-400 to-orange-600';
      default: return 'from-blue-400 to-blue-600';
    }
  };

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1: return 'bg-gradient-to-r from-yellow-400 to-yellow-600 text-white';
      case 2: return 'bg-gradient-to-r from-gray-300 to-gray-500 text-white';
      case 3: return 'bg-gradient-to-r from-orange-400 to-orange-600 text-white';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <section className="py-16 bg-gradient-to-br from-purple-50 via-indigo-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Trophy className="h-8 w-8 text-yellow-600" />
            <h2 className="text-3xl font-bold text-gray-900">Achievements & Leaderboard</h2>
          </div>
          <p className="text-lg text-gray-600">Celebrate your progress and compete with peers</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Badge Showcase */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Your Achievements</h3>
              
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {userBadges.map((badge, index) => (
                  <div key={index} className="text-center group cursor-pointer">
                    <div className={`w-20 h-20 mx-auto mb-3 rounded-full bg-gradient-to-br ${getBadgeColor(badge.type, badge.earned)} p-4 shadow-lg group-hover:scale-110 transition-transform relative`}>
                      <badge.icon className="w-full h-full text-white" />
                      {!badge.earned && (
                        <div className="absolute inset-0 bg-black bg-opacity-50 rounded-full flex items-center justify-center">
                          <span className="text-white text-xs font-bold">{badge.progress}%</span>
                        </div>
                      )}
                    </div>
                    <h4 className={`font-semibold text-sm mb-1 ${badge.earned ? 'text-gray-900' : 'text-gray-500'}`}>
                      {badge.name}
                    </h4>
                    <p className={`text-xs ${badge.earned ? 'text-gray-600' : 'text-gray-400'}`}>
                      {badge.description}
                    </p>
                    {badge.earned && badge.date && (
                      <p className="text-xs text-gray-500 mt-1">
                        Earned: {badge.date}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Progress Stats */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Progress Statistics</h3>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-1">2,650</div>
                  <div className="text-sm text-gray-600">Total Points</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 mb-1">5</div>
                  <div className="text-sm text-gray-600">Badges Earned</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-orange-600 mb-1">7</div>
                  <div className="text-sm text-gray-600">Day Streak</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600 mb-1">#2</div>
                  <div className="text-sm text-gray-600">Class Rank</div>
                </div>
              </div>

              <div className="mt-8">
                <h4 className="font-semibold text-gray-900 mb-4">Weekly Challenge Progress</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Complete 5 Quizzes</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-24 bg-gray-200 rounded-full h-2">
                        <div className="bg-green-500 rounded-full h-2" style={{ width: '80%' }}></div>
                      </div>
                      <span className="text-sm font-semibold text-gray-700">4/5</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Study 7 Days in a Row</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-24 bg-gray-200 rounded-full h-2">
                        <div className="bg-green-500 rounded-full h-2" style={{ width: '100%' }}></div>
                      </div>
                      <span className="text-sm font-semibold text-green-600">7/7 ✓</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Master 3 New Topics</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-24 bg-gray-200 rounded-full h-2">
                        <div className="bg-blue-500 rounded-full h-2" style={{ width: '66%' }}></div>
                      </div>
                      <span className="text-sm font-semibold text-gray-700">2/3</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Leaderboard */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-6">Class Leaderboard</h3>
            
            <div className="space-y-3">
              {leaderboard.map((student, index) => (
                <div key={index} className="flex items-center space-x-4 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${getRankColor(student.rank)}`}>
                    {student.rank}
                  </div>
                  
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                    {student.avatar}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-semibold text-gray-900 text-sm">{student.name}</p>
                      <div className="flex items-center space-x-1">
                        {student.change === 'up' && <span className="text-green-500 text-xs">↑</span>}
                        {student.change === 'down' && <span className="text-red-500 text-xs">↓</span>}
                        {student.change === 'same' && <span className="text-gray-400 text-xs">−</span>}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-blue-600 font-semibold text-sm">{student.points.toLocaleString()} pts</span>
                      <span className="text-gray-500 text-xs">{student.streak} day streak</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl">
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-2">Your current position</p>
                <div className="flex items-center justify-center space-x-2">
                  <div className="w-6 h-6 bg-gradient-to-r from-gray-300 to-gray-500 rounded-full flex items-center justify-center text-white font-bold text-xs">
                    2
                  </div>
                  <span className="font-semibold text-gray-900">You're 2nd place!</span>
                </div>
                <p className="text-xs text-gray-600 mt-1">
                  190 points behind 1st place
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}