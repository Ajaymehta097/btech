import React, { useState } from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import StudentProfile from './components/StudentProfile';
import SubjectSelection from './components/SubjectSelection';
import Dashboard from './components/Dashboard';
import QuizSection from './components/QuizSection';
import RecommendationPanel from './components/RecommendationPanel';
import ProjectsSection from './components/ProjectsSection';
import RevisionPlanner from './components/RevisionPlanner';
import TeacherDashboard from './components/TeacherDashboard';
import GamificationSection from './components/GamificationSection';
import Footer from './components/Footer';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [isTeacher, setIsTeacher] = useState(false);

  const handleToggleLogin = () => {
    setIsLoggedIn(!isLoggedIn);
  };

  const toggleTeacherMode = () => {
    setIsTeacher(!isTeacher);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        isLoggedIn={isLoggedIn} 
        isTeacher={isTeacher}
        onToggleLogin={handleToggleLogin} 
      />
      
      <main>
        <HeroSection />
        
        {isLoggedIn && !isTeacher && (
          <>
            <StudentProfile />
            <SubjectSelection />
            <Dashboard />
            <QuizSection />
            <RecommendationPanel />
            <ProjectsSection />
            <RevisionPlanner />
            <GamificationSection />
          </>
        )}
        
        {isTeacher && (
          <TeacherDashboard isVisible={true} />
        )}
      </main>

      <Footer />
      
      {/* Teacher Mode Toggle - Development Helper */}
      {isLoggedIn && (
        <button
          onClick={toggleTeacherMode}
          className="fixed bottom-4 right-4 bg-purple-600 text-white px-4 py-2 rounded-full text-sm font-medium hover:bg-purple-700 transition-colors shadow-lg z-50"
        >
          {isTeacher ? 'Student View' : 'Teacher View'}
        </button>
      )}
    </div>
  );
}

export default App;